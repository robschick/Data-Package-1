DataVersion: 0.1.2
=======================
* Added: series_range
* Changed: locations
* Changed: series
Package built in non-interactive mode

DataVersion: 0.1.1
=======================
* Added: series
* Changed: locations
Package built in non-interactive mode

DataVersion: 0.1.0
=======================
Package built in non-interactive mode

